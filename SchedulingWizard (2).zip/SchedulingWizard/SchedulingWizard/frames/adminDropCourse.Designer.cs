﻿namespace SchedulingWizard.frames
{
    partial class adminDropCourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.rbtn8 = new System.Windows.Forms.RadioButton();
            this.rbtn7 = new System.Windows.Forms.RadioButton();
            this.rbtn6 = new System.Windows.Forms.RadioButton();
            this.rbtn5 = new System.Windows.Forms.RadioButton();
            this.rbtn4 = new System.Windows.Forms.RadioButton();
            this.rbtn3 = new System.Windows.Forms.RadioButton();
            this.rbtn2 = new System.Windows.Forms.RadioButton();
            this.rbtn1 = new System.Windows.Forms.RadioButton();
            this.button3 = new System.Windows.Forms.Button();
            this.clbl8 = new System.Windows.Forms.Label();
            this.nlbl8 = new System.Windows.Forms.Label();
            this.clbl7 = new System.Windows.Forms.Label();
            this.nlbl7 = new System.Windows.Forms.Label();
            this.clbl6 = new System.Windows.Forms.Label();
            this.nlbl6 = new System.Windows.Forms.Label();
            this.clbl5 = new System.Windows.Forms.Label();
            this.nlbl5 = new System.Windows.Forms.Label();
            this.clbl4 = new System.Windows.Forms.Label();
            this.nlbl4 = new System.Windows.Forms.Label();
            this.clbl3 = new System.Windows.Forms.Label();
            this.nlbl3 = new System.Windows.Forms.Label();
            this.clbl2 = new System.Windows.Forms.Label();
            this.nlbl2 = new System.Windows.Forms.Label();
            this.clbl1 = new System.Windows.Forms.Label();
            this.nlbl1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.searchLabel = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(120, 581);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(81, 44);
            this.button6.TabIndex = 68;
            this.button6.Text = "View";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.showCourseInfo);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(33, 581);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 44);
            this.button4.TabIndex = 67;
            this.button4.Text = "Drop";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.dropCourse);
            // 
            // rbtn8
            // 
            this.rbtn8.AutoSize = true;
            this.rbtn8.Location = new System.Drawing.Point(679, 524);
            this.rbtn8.Name = "rbtn8";
            this.rbtn8.Size = new System.Drawing.Size(17, 16);
            this.rbtn8.TabIndex = 66;
            this.rbtn8.TabStop = true;
            this.rbtn8.UseVisualStyleBackColor = true;
            // 
            // rbtn7
            // 
            this.rbtn7.AutoSize = true;
            this.rbtn7.Location = new System.Drawing.Point(679, 472);
            this.rbtn7.Name = "rbtn7";
            this.rbtn7.Size = new System.Drawing.Size(17, 16);
            this.rbtn7.TabIndex = 65;
            this.rbtn7.TabStop = true;
            this.rbtn7.UseVisualStyleBackColor = true;
            // 
            // rbtn6
            // 
            this.rbtn6.AutoSize = true;
            this.rbtn6.Location = new System.Drawing.Point(679, 416);
            this.rbtn6.Name = "rbtn6";
            this.rbtn6.Size = new System.Drawing.Size(17, 16);
            this.rbtn6.TabIndex = 64;
            this.rbtn6.TabStop = true;
            this.rbtn6.UseVisualStyleBackColor = true;
            // 
            // rbtn5
            // 
            this.rbtn5.AutoSize = true;
            this.rbtn5.Location = new System.Drawing.Point(679, 359);
            this.rbtn5.Name = "rbtn5";
            this.rbtn5.Size = new System.Drawing.Size(17, 16);
            this.rbtn5.TabIndex = 63;
            this.rbtn5.TabStop = true;
            this.rbtn5.UseVisualStyleBackColor = true;
            // 
            // rbtn4
            // 
            this.rbtn4.AutoSize = true;
            this.rbtn4.Location = new System.Drawing.Point(679, 305);
            this.rbtn4.Name = "rbtn4";
            this.rbtn4.Size = new System.Drawing.Size(17, 16);
            this.rbtn4.TabIndex = 62;
            this.rbtn4.TabStop = true;
            this.rbtn4.UseVisualStyleBackColor = true;
            // 
            // rbtn3
            // 
            this.rbtn3.AutoSize = true;
            this.rbtn3.Location = new System.Drawing.Point(679, 249);
            this.rbtn3.Name = "rbtn3";
            this.rbtn3.Size = new System.Drawing.Size(17, 16);
            this.rbtn3.TabIndex = 61;
            this.rbtn3.TabStop = true;
            this.rbtn3.UseVisualStyleBackColor = true;
            // 
            // rbtn2
            // 
            this.rbtn2.AutoSize = true;
            this.rbtn2.Location = new System.Drawing.Point(679, 192);
            this.rbtn2.Name = "rbtn2";
            this.rbtn2.Size = new System.Drawing.Size(17, 16);
            this.rbtn2.TabIndex = 60;
            this.rbtn2.TabStop = true;
            this.rbtn2.UseVisualStyleBackColor = true;
            // 
            // rbtn1
            // 
            this.rbtn1.AutoSize = true;
            this.rbtn1.Location = new System.Drawing.Point(679, 138);
            this.rbtn1.Name = "rbtn1";
            this.rbtn1.Size = new System.Drawing.Size(17, 16);
            this.rbtn1.TabIndex = 59;
            this.rbtn1.TabStop = true;
            this.rbtn1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::SchedulingWizard.Properties.Resources.icons8_search_more_32px;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(553, 588);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(206, 37);
            this.button3.TabIndex = 58;
            this.button3.Text = "Next page";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.nxtPage);
            // 
            // clbl8
            // 
            this.clbl8.AutoSize = true;
            this.clbl8.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl8.ForeColor = System.Drawing.Color.White;
            this.clbl8.Location = new System.Drawing.Point(109, 515);
            this.clbl8.Name = "clbl8";
            this.clbl8.Size = new System.Drawing.Size(145, 39);
            this.clbl8.TabIndex = 57;
            this.clbl8.Text = "first User";
            // 
            // nlbl8
            // 
            this.nlbl8.AutoSize = true;
            this.nlbl8.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl8.ForeColor = System.Drawing.Color.White;
            this.nlbl8.Location = new System.Drawing.Point(44, 515);
            this.nlbl8.Name = "nlbl8";
            this.nlbl8.Size = new System.Drawing.Size(43, 39);
            this.nlbl8.TabIndex = 56;
            this.nlbl8.Text = "1.";
            // 
            // clbl7
            // 
            this.clbl7.AutoSize = true;
            this.clbl7.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl7.ForeColor = System.Drawing.Color.White;
            this.clbl7.Location = new System.Drawing.Point(109, 463);
            this.clbl7.Name = "clbl7";
            this.clbl7.Size = new System.Drawing.Size(145, 39);
            this.clbl7.TabIndex = 55;
            this.clbl7.Text = "first User";
            // 
            // nlbl7
            // 
            this.nlbl7.AutoSize = true;
            this.nlbl7.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl7.ForeColor = System.Drawing.Color.White;
            this.nlbl7.Location = new System.Drawing.Point(44, 463);
            this.nlbl7.Name = "nlbl7";
            this.nlbl7.Size = new System.Drawing.Size(43, 39);
            this.nlbl7.TabIndex = 54;
            this.nlbl7.Text = "1.";
            // 
            // clbl6
            // 
            this.clbl6.AutoSize = true;
            this.clbl6.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl6.ForeColor = System.Drawing.Color.White;
            this.clbl6.Location = new System.Drawing.Point(109, 407);
            this.clbl6.Name = "clbl6";
            this.clbl6.Size = new System.Drawing.Size(145, 39);
            this.clbl6.TabIndex = 53;
            this.clbl6.Text = "first User";
            // 
            // nlbl6
            // 
            this.nlbl6.AutoSize = true;
            this.nlbl6.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl6.ForeColor = System.Drawing.Color.White;
            this.nlbl6.Location = new System.Drawing.Point(44, 407);
            this.nlbl6.Name = "nlbl6";
            this.nlbl6.Size = new System.Drawing.Size(43, 39);
            this.nlbl6.TabIndex = 52;
            this.nlbl6.Text = "1.";
            // 
            // clbl5
            // 
            this.clbl5.AutoSize = true;
            this.clbl5.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl5.ForeColor = System.Drawing.Color.White;
            this.clbl5.Location = new System.Drawing.Point(109, 352);
            this.clbl5.Name = "clbl5";
            this.clbl5.Size = new System.Drawing.Size(145, 39);
            this.clbl5.TabIndex = 51;
            this.clbl5.Text = "first User";
            // 
            // nlbl5
            // 
            this.nlbl5.AutoSize = true;
            this.nlbl5.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl5.ForeColor = System.Drawing.Color.White;
            this.nlbl5.Location = new System.Drawing.Point(44, 352);
            this.nlbl5.Name = "nlbl5";
            this.nlbl5.Size = new System.Drawing.Size(43, 39);
            this.nlbl5.TabIndex = 50;
            this.nlbl5.Text = "1.";
            // 
            // clbl4
            // 
            this.clbl4.AutoSize = true;
            this.clbl4.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl4.ForeColor = System.Drawing.Color.White;
            this.clbl4.Location = new System.Drawing.Point(109, 296);
            this.clbl4.Name = "clbl4";
            this.clbl4.Size = new System.Drawing.Size(145, 39);
            this.clbl4.TabIndex = 49;
            this.clbl4.Text = "first User";
            // 
            // nlbl4
            // 
            this.nlbl4.AutoSize = true;
            this.nlbl4.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl4.ForeColor = System.Drawing.Color.White;
            this.nlbl4.Location = new System.Drawing.Point(44, 296);
            this.nlbl4.Name = "nlbl4";
            this.nlbl4.Size = new System.Drawing.Size(43, 39);
            this.nlbl4.TabIndex = 48;
            this.nlbl4.Text = "1.";
            // 
            // clbl3
            // 
            this.clbl3.AutoSize = true;
            this.clbl3.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl3.ForeColor = System.Drawing.Color.White;
            this.clbl3.Location = new System.Drawing.Point(109, 240);
            this.clbl3.Name = "clbl3";
            this.clbl3.Size = new System.Drawing.Size(145, 39);
            this.clbl3.TabIndex = 47;
            this.clbl3.Text = "first User";
            // 
            // nlbl3
            // 
            this.nlbl3.AutoSize = true;
            this.nlbl3.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl3.ForeColor = System.Drawing.Color.White;
            this.nlbl3.Location = new System.Drawing.Point(44, 240);
            this.nlbl3.Name = "nlbl3";
            this.nlbl3.Size = new System.Drawing.Size(43, 39);
            this.nlbl3.TabIndex = 46;
            this.nlbl3.Text = "1.";
            // 
            // clbl2
            // 
            this.clbl2.AutoSize = true;
            this.clbl2.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl2.ForeColor = System.Drawing.Color.White;
            this.clbl2.Location = new System.Drawing.Point(109, 183);
            this.clbl2.Name = "clbl2";
            this.clbl2.Size = new System.Drawing.Size(145, 39);
            this.clbl2.TabIndex = 45;
            this.clbl2.Text = "first User";
            // 
            // nlbl2
            // 
            this.nlbl2.AutoSize = true;
            this.nlbl2.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl2.ForeColor = System.Drawing.Color.White;
            this.nlbl2.Location = new System.Drawing.Point(44, 183);
            this.nlbl2.Name = "nlbl2";
            this.nlbl2.Size = new System.Drawing.Size(43, 39);
            this.nlbl2.TabIndex = 44;
            this.nlbl2.Text = "1.";
            // 
            // clbl1
            // 
            this.clbl1.AutoSize = true;
            this.clbl1.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl1.ForeColor = System.Drawing.Color.White;
            this.clbl1.Location = new System.Drawing.Point(109, 129);
            this.clbl1.Name = "clbl1";
            this.clbl1.Size = new System.Drawing.Size(145, 39);
            this.clbl1.TabIndex = 43;
            this.clbl1.Text = "first User";
            // 
            // nlbl1
            // 
            this.nlbl1.AutoSize = true;
            this.nlbl1.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl1.ForeColor = System.Drawing.Color.White;
            this.nlbl1.Location = new System.Drawing.Point(44, 129);
            this.nlbl1.Name = "nlbl1";
            this.nlbl1.Size = new System.Drawing.Size(43, 39);
            this.nlbl1.TabIndex = 42;
            this.nlbl1.Text = "1.";
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = global::SchedulingWizard.Properties.Resources.icons8_arrow_pointing_left_30px;
            this.button5.Location = new System.Drawing.Point(3, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 35);
            this.button5.TabIndex = 41;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.prevPage);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(703, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(34, 35);
            this.button2.TabIndex = 40;
            this.button2.Text = "_";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.minimizeWindow);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(743, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 35);
            this.button1.TabIndex = 39;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.appExit);
            // 
            // Title
            // 
            this.Title.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(133, 50);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(548, 51);
            this.Title.TabIndex = 38;
            this.Title.Text = "Showing Course Information";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 38);
            this.panel1.TabIndex = 69;
            // 
            // searchLabel
            // 
            this.searchLabel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchLabel.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.searchLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.searchLabel.HintForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.searchLabel.HintText = "Search Specific Course";
            this.searchLabel.isPassword = false;
            this.searchLabel.LineFocusedColor = System.Drawing.Color.Blue;
            this.searchLabel.LineIdleColor = System.Drawing.Color.Gray;
            this.searchLabel.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.searchLabel.LineThickness = 3;
            this.searchLabel.Location = new System.Drawing.Point(218, 581);
            this.searchLabel.Margin = new System.Windows.Forms.Padding(4);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(359, 44);
            this.searchLabel.TabIndex = 70;
            this.searchLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchLabel.OnValueChanged += new System.EventHandler(this.searchCourse);
            // 
            // adminDropCourse
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(782, 672);
            this.Controls.Add(this.searchLabel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.rbtn8);
            this.Controls.Add(this.rbtn7);
            this.Controls.Add(this.rbtn6);
            this.Controls.Add(this.rbtn5);
            this.Controls.Add(this.rbtn4);
            this.Controls.Add(this.rbtn3);
            this.Controls.Add(this.rbtn2);
            this.Controls.Add(this.rbtn1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.clbl8);
            this.Controls.Add(this.nlbl8);
            this.Controls.Add(this.clbl7);
            this.Controls.Add(this.nlbl7);
            this.Controls.Add(this.clbl6);
            this.Controls.Add(this.nlbl6);
            this.Controls.Add(this.clbl5);
            this.Controls.Add(this.nlbl5);
            this.Controls.Add(this.clbl4);
            this.Controls.Add(this.nlbl4);
            this.Controls.Add(this.clbl3);
            this.Controls.Add(this.nlbl3);
            this.Controls.Add(this.clbl2);
            this.Controls.Add(this.nlbl2);
            this.Controls.Add(this.clbl1);
            this.Controls.Add(this.nlbl1);
            this.Controls.Add(this.Title);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "adminDropCourse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton rbtn8;
        private System.Windows.Forms.RadioButton rbtn7;
        private System.Windows.Forms.RadioButton rbtn6;
        private System.Windows.Forms.RadioButton rbtn5;
        private System.Windows.Forms.RadioButton rbtn4;
        private System.Windows.Forms.RadioButton rbtn3;
        private System.Windows.Forms.RadioButton rbtn2;
        private System.Windows.Forms.RadioButton rbtn1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label clbl8;
        private System.Windows.Forms.Label nlbl8;
        private System.Windows.Forms.Label clbl7;
        private System.Windows.Forms.Label nlbl7;
        private System.Windows.Forms.Label clbl6;
        private System.Windows.Forms.Label nlbl6;
        private System.Windows.Forms.Label clbl5;
        private System.Windows.Forms.Label nlbl5;
        private System.Windows.Forms.Label clbl4;
        private System.Windows.Forms.Label nlbl4;
        private System.Windows.Forms.Label clbl3;
        private System.Windows.Forms.Label nlbl3;
        private System.Windows.Forms.Label clbl2;
        private System.Windows.Forms.Label nlbl2;
        private System.Windows.Forms.Label clbl1;
        private System.Windows.Forms.Label nlbl1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox searchLabel;
    }
}