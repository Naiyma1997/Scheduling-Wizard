﻿namespace SchedulingWizard.frames
{
    partial class resultsForMore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.routineLabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tlbl20 = new System.Windows.Forms.Label();
            this.tlbl19 = new System.Windows.Forms.Label();
            this.clbl10 = new System.Windows.Forms.Label();
            this.tlbl18 = new System.Windows.Forms.Label();
            this.tlbl17 = new System.Windows.Forms.Label();
            this.clbl9 = new System.Windows.Forms.Label();
            this.tlbl16 = new System.Windows.Forms.Label();
            this.tlbl15 = new System.Windows.Forms.Label();
            this.clbl8 = new System.Windows.Forms.Label();
            this.tlbl14 = new System.Windows.Forms.Label();
            this.tlbl13 = new System.Windows.Forms.Label();
            this.clbl7 = new System.Windows.Forms.Label();
            this.tlbl12 = new System.Windows.Forms.Label();
            this.tlbl11 = new System.Windows.Forms.Label();
            this.clbl6 = new System.Windows.Forms.Label();
            this.tlbl10 = new System.Windows.Forms.Label();
            this.tlbl9 = new System.Windows.Forms.Label();
            this.clbl5 = new System.Windows.Forms.Label();
            this.tlbl8 = new System.Windows.Forms.Label();
            this.tlbl7 = new System.Windows.Forms.Label();
            this.clbl4 = new System.Windows.Forms.Label();
            this.tlbl6 = new System.Windows.Forms.Label();
            this.tlbl5 = new System.Windows.Forms.Label();
            this.clbl3 = new System.Windows.Forms.Label();
            this.tlbl4 = new System.Windows.Forms.Label();
            this.tlbl3 = new System.Windows.Forms.Label();
            this.clbl2 = new System.Windows.Forms.Label();
            this.tlbl2 = new System.Windows.Forms.Label();
            this.tlbl1 = new System.Windows.Forms.Label();
            this.clbl1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pageShow = new System.Windows.Forms.Label();
            this.nxtBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.routineLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(965, 87);
            this.panel1.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Image = global::SchedulingWizard.Properties.Resources.icons8_arrow_pointing_left_30px;
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 41);
            this.button3.TabIndex = 11;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.prevPage);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Location = new System.Drawing.Point(830, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(123, 41);
            this.panel4.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkRed;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 41);
            this.button2.TabIndex = 1;
            this.button2.Text = "-";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.MinimizeWindow);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkRed;
            this.button1.Location = new System.Drawing.Point(58, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 41);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.closeApp);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SchedulingWizard.Properties.Resources.icons8_todo_list_200px;
            this.pictureBox1.Location = new System.Drawing.Point(309, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // routineLabel
            // 
            this.routineLabel.AutoSize = true;
            this.routineLabel.Font = new System.Drawing.Font("Palatino Linotype", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.routineLabel.ForeColor = System.Drawing.Color.Maroon;
            this.routineLabel.Location = new System.Drawing.Point(384, 9);
            this.routineLabel.Name = "routineLabel";
            this.routineLabel.Size = new System.Drawing.Size(195, 64);
            this.routineLabel.TabIndex = 6;
            this.routineLabel.Text = "Routine";
            this.routineLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.tlbl20);
            this.panel2.Controls.Add(this.tlbl19);
            this.panel2.Controls.Add(this.clbl10);
            this.panel2.Controls.Add(this.tlbl18);
            this.panel2.Controls.Add(this.tlbl17);
            this.panel2.Controls.Add(this.clbl9);
            this.panel2.Controls.Add(this.tlbl16);
            this.panel2.Controls.Add(this.tlbl15);
            this.panel2.Controls.Add(this.clbl8);
            this.panel2.Controls.Add(this.tlbl14);
            this.panel2.Controls.Add(this.tlbl13);
            this.panel2.Controls.Add(this.clbl7);
            this.panel2.Controls.Add(this.tlbl12);
            this.panel2.Controls.Add(this.tlbl11);
            this.panel2.Controls.Add(this.clbl6);
            this.panel2.Controls.Add(this.tlbl10);
            this.panel2.Controls.Add(this.tlbl9);
            this.panel2.Controls.Add(this.clbl5);
            this.panel2.Controls.Add(this.tlbl8);
            this.panel2.Controls.Add(this.tlbl7);
            this.panel2.Controls.Add(this.clbl4);
            this.panel2.Controls.Add(this.tlbl6);
            this.panel2.Controls.Add(this.tlbl5);
            this.panel2.Controls.Add(this.clbl3);
            this.panel2.Controls.Add(this.tlbl4);
            this.panel2.Controls.Add(this.tlbl3);
            this.panel2.Controls.Add(this.clbl2);
            this.panel2.Controls.Add(this.tlbl2);
            this.panel2.Controls.Add(this.tlbl1);
            this.panel2.Controls.Add(this.clbl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(965, 613);
            this.panel2.TabIndex = 1;
            // 
            // tlbl20
            // 
            this.tlbl20.AutoSize = true;
            this.tlbl20.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl20.ForeColor = System.Drawing.Color.Black;
            this.tlbl20.Location = new System.Drawing.Point(551, 488);
            this.tlbl20.Name = "tlbl20";
            this.tlbl20.Size = new System.Drawing.Size(191, 23);
            this.tlbl20.TabIndex = 32;
            this.tlbl20.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl19
            // 
            this.tlbl19.AutoSize = true;
            this.tlbl19.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl19.ForeColor = System.Drawing.Color.Black;
            this.tlbl19.Location = new System.Drawing.Point(551, 465);
            this.tlbl19.Name = "tlbl19";
            this.tlbl19.Size = new System.Drawing.Size(184, 23);
            this.tlbl19.TabIndex = 31;
            this.tlbl19.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl10
            // 
            this.clbl10.AutoSize = true;
            this.clbl10.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl10.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl10.Location = new System.Drawing.Point(551, 427);
            this.clbl10.Name = "clbl10";
            this.clbl10.Size = new System.Drawing.Size(307, 29);
            this.clbl10.TabIndex = 30;
            this.clbl10.Text = "Basic Graph Theory";
            // 
            // tlbl18
            // 
            this.tlbl18.AutoSize = true;
            this.tlbl18.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl18.ForeColor = System.Drawing.Color.Black;
            this.tlbl18.Location = new System.Drawing.Point(551, 385);
            this.tlbl18.Name = "tlbl18";
            this.tlbl18.Size = new System.Drawing.Size(191, 23);
            this.tlbl18.TabIndex = 29;
            this.tlbl18.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl17
            // 
            this.tlbl17.AutoSize = true;
            this.tlbl17.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl17.ForeColor = System.Drawing.Color.Black;
            this.tlbl17.Location = new System.Drawing.Point(551, 362);
            this.tlbl17.Name = "tlbl17";
            this.tlbl17.Size = new System.Drawing.Size(184, 23);
            this.tlbl17.TabIndex = 28;
            this.tlbl17.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl9
            // 
            this.clbl9.AutoSize = true;
            this.clbl9.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl9.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl9.Location = new System.Drawing.Point(551, 324);
            this.clbl9.Name = "clbl9";
            this.clbl9.Size = new System.Drawing.Size(307, 29);
            this.clbl9.TabIndex = 27;
            this.clbl9.Text = "Basic Graph Theory";
            // 
            // tlbl16
            // 
            this.tlbl16.AutoSize = true;
            this.tlbl16.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl16.ForeColor = System.Drawing.Color.Black;
            this.tlbl16.Location = new System.Drawing.Point(551, 282);
            this.tlbl16.Name = "tlbl16";
            this.tlbl16.Size = new System.Drawing.Size(191, 23);
            this.tlbl16.TabIndex = 26;
            this.tlbl16.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl15
            // 
            this.tlbl15.AutoSize = true;
            this.tlbl15.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl15.ForeColor = System.Drawing.Color.Black;
            this.tlbl15.Location = new System.Drawing.Point(551, 259);
            this.tlbl15.Name = "tlbl15";
            this.tlbl15.Size = new System.Drawing.Size(184, 23);
            this.tlbl15.TabIndex = 25;
            this.tlbl15.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl8
            // 
            this.clbl8.AutoSize = true;
            this.clbl8.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl8.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl8.Location = new System.Drawing.Point(551, 221);
            this.clbl8.Name = "clbl8";
            this.clbl8.Size = new System.Drawing.Size(307, 29);
            this.clbl8.TabIndex = 24;
            this.clbl8.Text = "Basic Graph Theory";
            // 
            // tlbl14
            // 
            this.tlbl14.AutoSize = true;
            this.tlbl14.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl14.ForeColor = System.Drawing.Color.Black;
            this.tlbl14.Location = new System.Drawing.Point(551, 186);
            this.tlbl14.Name = "tlbl14";
            this.tlbl14.Size = new System.Drawing.Size(191, 23);
            this.tlbl14.TabIndex = 23;
            this.tlbl14.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl13
            // 
            this.tlbl13.AutoSize = true;
            this.tlbl13.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl13.ForeColor = System.Drawing.Color.Black;
            this.tlbl13.Location = new System.Drawing.Point(551, 163);
            this.tlbl13.Name = "tlbl13";
            this.tlbl13.Size = new System.Drawing.Size(184, 23);
            this.tlbl13.TabIndex = 22;
            this.tlbl13.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl7
            // 
            this.clbl7.AutoSize = true;
            this.clbl7.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl7.Location = new System.Drawing.Point(551, 125);
            this.clbl7.Name = "clbl7";
            this.clbl7.Size = new System.Drawing.Size(307, 29);
            this.clbl7.TabIndex = 21;
            this.clbl7.Text = "Basic Graph Theory";
            // 
            // tlbl12
            // 
            this.tlbl12.AutoSize = true;
            this.tlbl12.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl12.ForeColor = System.Drawing.Color.Black;
            this.tlbl12.Location = new System.Drawing.Point(551, 88);
            this.tlbl12.Name = "tlbl12";
            this.tlbl12.Size = new System.Drawing.Size(191, 23);
            this.tlbl12.TabIndex = 20;
            this.tlbl12.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl11
            // 
            this.tlbl11.AutoSize = true;
            this.tlbl11.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl11.ForeColor = System.Drawing.Color.Black;
            this.tlbl11.Location = new System.Drawing.Point(551, 65);
            this.tlbl11.Name = "tlbl11";
            this.tlbl11.Size = new System.Drawing.Size(184, 23);
            this.tlbl11.TabIndex = 19;
            this.tlbl11.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl6
            // 
            this.clbl6.AutoSize = true;
            this.clbl6.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl6.Location = new System.Drawing.Point(551, 27);
            this.clbl6.Name = "clbl6";
            this.clbl6.Size = new System.Drawing.Size(307, 29);
            this.clbl6.TabIndex = 18;
            this.clbl6.Text = "Basic Graph Theory";
            // 
            // tlbl10
            // 
            this.tlbl10.AutoSize = true;
            this.tlbl10.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl10.ForeColor = System.Drawing.Color.Black;
            this.tlbl10.Location = new System.Drawing.Point(21, 488);
            this.tlbl10.Name = "tlbl10";
            this.tlbl10.Size = new System.Drawing.Size(191, 23);
            this.tlbl10.TabIndex = 17;
            this.tlbl10.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl9
            // 
            this.tlbl9.AutoSize = true;
            this.tlbl9.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl9.ForeColor = System.Drawing.Color.Black;
            this.tlbl9.Location = new System.Drawing.Point(21, 465);
            this.tlbl9.Name = "tlbl9";
            this.tlbl9.Size = new System.Drawing.Size(184, 23);
            this.tlbl9.TabIndex = 16;
            this.tlbl9.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl5
            // 
            this.clbl5.AutoSize = true;
            this.clbl5.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl5.Location = new System.Drawing.Point(21, 427);
            this.clbl5.Name = "clbl5";
            this.clbl5.Size = new System.Drawing.Size(307, 29);
            this.clbl5.TabIndex = 15;
            this.clbl5.Text = "Basic Graph Theory";
            // 
            // tlbl8
            // 
            this.tlbl8.AutoSize = true;
            this.tlbl8.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl8.ForeColor = System.Drawing.Color.Black;
            this.tlbl8.Location = new System.Drawing.Point(21, 385);
            this.tlbl8.Name = "tlbl8";
            this.tlbl8.Size = new System.Drawing.Size(191, 23);
            this.tlbl8.TabIndex = 14;
            this.tlbl8.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl7
            // 
            this.tlbl7.AutoSize = true;
            this.tlbl7.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl7.ForeColor = System.Drawing.Color.Black;
            this.tlbl7.Location = new System.Drawing.Point(21, 362);
            this.tlbl7.Name = "tlbl7";
            this.tlbl7.Size = new System.Drawing.Size(184, 23);
            this.tlbl7.TabIndex = 13;
            this.tlbl7.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl4
            // 
            this.clbl4.AutoSize = true;
            this.clbl4.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl4.Location = new System.Drawing.Point(21, 324);
            this.clbl4.Name = "clbl4";
            this.clbl4.Size = new System.Drawing.Size(307, 29);
            this.clbl4.TabIndex = 12;
            this.clbl4.Text = "Basic Graph Theory";
            // 
            // tlbl6
            // 
            this.tlbl6.AutoSize = true;
            this.tlbl6.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl6.ForeColor = System.Drawing.Color.Black;
            this.tlbl6.Location = new System.Drawing.Point(21, 282);
            this.tlbl6.Name = "tlbl6";
            this.tlbl6.Size = new System.Drawing.Size(191, 23);
            this.tlbl6.TabIndex = 11;
            this.tlbl6.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl5
            // 
            this.tlbl5.AutoSize = true;
            this.tlbl5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl5.ForeColor = System.Drawing.Color.Black;
            this.tlbl5.Location = new System.Drawing.Point(21, 259);
            this.tlbl5.Name = "tlbl5";
            this.tlbl5.Size = new System.Drawing.Size(184, 23);
            this.tlbl5.TabIndex = 10;
            this.tlbl5.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl3
            // 
            this.clbl3.AutoSize = true;
            this.clbl3.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl3.Location = new System.Drawing.Point(21, 221);
            this.clbl3.Name = "clbl3";
            this.clbl3.Size = new System.Drawing.Size(307, 29);
            this.clbl3.TabIndex = 9;
            this.clbl3.Text = "Basic Graph Theory";
            // 
            // tlbl4
            // 
            this.tlbl4.AutoSize = true;
            this.tlbl4.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl4.ForeColor = System.Drawing.Color.Black;
            this.tlbl4.Location = new System.Drawing.Point(21, 186);
            this.tlbl4.Name = "tlbl4";
            this.tlbl4.Size = new System.Drawing.Size(191, 23);
            this.tlbl4.TabIndex = 8;
            this.tlbl4.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl3
            // 
            this.tlbl3.AutoSize = true;
            this.tlbl3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl3.ForeColor = System.Drawing.Color.Black;
            this.tlbl3.Location = new System.Drawing.Point(21, 163);
            this.tlbl3.Name = "tlbl3";
            this.tlbl3.Size = new System.Drawing.Size(184, 23);
            this.tlbl3.TabIndex = 7;
            this.tlbl3.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl2
            // 
            this.clbl2.AutoSize = true;
            this.clbl2.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl2.Location = new System.Drawing.Point(21, 125);
            this.clbl2.Name = "clbl2";
            this.clbl2.Size = new System.Drawing.Size(307, 29);
            this.clbl2.TabIndex = 6;
            this.clbl2.Text = "Basic Graph Theory";
            // 
            // tlbl2
            // 
            this.tlbl2.AutoSize = true;
            this.tlbl2.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl2.ForeColor = System.Drawing.Color.Black;
            this.tlbl2.Location = new System.Drawing.Point(21, 88);
            this.tlbl2.Name = "tlbl2";
            this.tlbl2.Size = new System.Drawing.Size(191, 23);
            this.tlbl2.TabIndex = 5;
            this.tlbl2.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl1
            // 
            this.tlbl1.AutoSize = true;
            this.tlbl1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl1.ForeColor = System.Drawing.Color.Black;
            this.tlbl1.Location = new System.Drawing.Point(21, 65);
            this.tlbl1.Name = "tlbl1";
            this.tlbl1.Size = new System.Drawing.Size(184, 23);
            this.tlbl1.TabIndex = 4;
            this.tlbl1.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl1
            // 
            this.clbl1.AutoSize = true;
            this.clbl1.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl1.Location = new System.Drawing.Point(21, 27);
            this.clbl1.Name = "clbl1";
            this.clbl1.Size = new System.Drawing.Size(307, 29);
            this.clbl1.TabIndex = 3;
            this.clbl1.Text = "Basic Graph Theory";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.pageShow);
            this.panel3.Controls.Add(this.nxtBtn);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 648);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(965, 52);
            this.panel3.TabIndex = 2;
            // 
            // pageShow
            // 
            this.pageShow.AutoSize = true;
            this.pageShow.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pageShow.ForeColor = System.Drawing.Color.White;
            this.pageShow.Location = new System.Drawing.Point(7, 0);
            this.pageShow.Name = "pageShow";
            this.pageShow.Size = new System.Drawing.Size(54, 30);
            this.pageShow.TabIndex = 8;
            this.pageShow.Text = "Page";
            // 
            // nxtBtn
            // 
            this.nxtBtn.BackColor = System.Drawing.Color.Red;
            this.nxtBtn.FlatAppearance.BorderSize = 0;
            this.nxtBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nxtBtn.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nxtBtn.ForeColor = System.Drawing.Color.White;
            this.nxtBtn.Image = global::SchedulingWizard.Properties.Resources.icons8_search_more_32px;
            this.nxtBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nxtBtn.Location = new System.Drawing.Point(726, 0);
            this.nxtBtn.Name = "nxtBtn";
            this.nxtBtn.Size = new System.Drawing.Size(239, 53);
            this.nxtBtn.TabIndex = 7;
            this.nxtBtn.Text = "Next Result";
            this.nxtBtn.UseVisualStyleBackColor = false;
            this.nxtBtn.Click += new System.EventHandler(this.nxtResult);
            // 
            // resultsForMore
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(965, 700);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "resultsForMore";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "resultsForMore";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label routineLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button nxtBtn;
        private System.Windows.Forms.Label tlbl20;
        private System.Windows.Forms.Label tlbl19;
        private System.Windows.Forms.Label clbl10;
        private System.Windows.Forms.Label tlbl18;
        private System.Windows.Forms.Label tlbl17;
        private System.Windows.Forms.Label clbl9;
        private System.Windows.Forms.Label tlbl16;
        private System.Windows.Forms.Label tlbl15;
        private System.Windows.Forms.Label clbl8;
        private System.Windows.Forms.Label tlbl14;
        private System.Windows.Forms.Label tlbl13;
        private System.Windows.Forms.Label clbl7;
        private System.Windows.Forms.Label tlbl12;
        private System.Windows.Forms.Label tlbl11;
        private System.Windows.Forms.Label clbl6;
        private System.Windows.Forms.Label tlbl10;
        private System.Windows.Forms.Label tlbl9;
        private System.Windows.Forms.Label clbl5;
        private System.Windows.Forms.Label tlbl8;
        private System.Windows.Forms.Label tlbl7;
        private System.Windows.Forms.Label clbl4;
        private System.Windows.Forms.Label tlbl6;
        private System.Windows.Forms.Label tlbl5;
        private System.Windows.Forms.Label clbl3;
        private System.Windows.Forms.Label tlbl4;
        private System.Windows.Forms.Label tlbl3;
        private System.Windows.Forms.Label clbl2;
        private System.Windows.Forms.Label tlbl2;
        private System.Windows.Forms.Label tlbl1;
        private System.Windows.Forms.Label clbl1;
        private System.Windows.Forms.Label pageShow;
    }
}