﻿namespace SchedulingWizard.frames
{
    partial class scheduleResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultShowPnl = new System.Windows.Forms.Panel();
            this.tlbl10 = new System.Windows.Forms.Label();
            this.tlbl9 = new System.Windows.Forms.Label();
            this.clbl5 = new System.Windows.Forms.Label();
            this.tlbl8 = new System.Windows.Forms.Label();
            this.tlbl7 = new System.Windows.Forms.Label();
            this.clbl4 = new System.Windows.Forms.Label();
            this.tlbl6 = new System.Windows.Forms.Label();
            this.tlbl5 = new System.Windows.Forms.Label();
            this.clbl3 = new System.Windows.Forms.Label();
            this.tlbl4 = new System.Windows.Forms.Label();
            this.tlbl3 = new System.Windows.Forms.Label();
            this.clbl2 = new System.Windows.Forms.Label();
            this.tlbl2 = new System.Windows.Forms.Label();
            this.tlbl1 = new System.Windows.Forms.Label();
            this.clbl1 = new System.Windows.Forms.Label();
            this.finalPnl = new System.Windows.Forms.Panel();
            this.pageShow = new System.Windows.Forms.Label();
            this.nxtBtn = new System.Windows.Forms.Button();
            this.introductoryPnl = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.routineLabel = new System.Windows.Forms.Label();
            this.resultShowPnl.SuspendLayout();
            this.finalPnl.SuspendLayout();
            this.introductoryPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // resultShowPnl
            // 
            this.resultShowPnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.resultShowPnl.Controls.Add(this.tlbl10);
            this.resultShowPnl.Controls.Add(this.tlbl9);
            this.resultShowPnl.Controls.Add(this.clbl5);
            this.resultShowPnl.Controls.Add(this.tlbl8);
            this.resultShowPnl.Controls.Add(this.tlbl7);
            this.resultShowPnl.Controls.Add(this.clbl4);
            this.resultShowPnl.Controls.Add(this.tlbl6);
            this.resultShowPnl.Controls.Add(this.tlbl5);
            this.resultShowPnl.Controls.Add(this.clbl3);
            this.resultShowPnl.Controls.Add(this.tlbl4);
            this.resultShowPnl.Controls.Add(this.tlbl3);
            this.resultShowPnl.Controls.Add(this.clbl2);
            this.resultShowPnl.Controls.Add(this.tlbl2);
            this.resultShowPnl.Controls.Add(this.tlbl1);
            this.resultShowPnl.Controls.Add(this.clbl1);
            this.resultShowPnl.Location = new System.Drawing.Point(0, 86);
            this.resultShowPnl.Name = "resultShowPnl";
            this.resultShowPnl.Size = new System.Drawing.Size(793, 610);
            this.resultShowPnl.TabIndex = 0;
            // 
            // tlbl10
            // 
            this.tlbl10.AutoSize = true;
            this.tlbl10.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl10.ForeColor = System.Drawing.Color.Black;
            this.tlbl10.Location = new System.Drawing.Point(24, 562);
            this.tlbl10.Name = "tlbl10";
            this.tlbl10.Size = new System.Drawing.Size(227, 28);
            this.tlbl10.TabIndex = 14;
            this.tlbl10.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl9
            // 
            this.tlbl9.AutoSize = true;
            this.tlbl9.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl9.ForeColor = System.Drawing.Color.Black;
            this.tlbl9.Location = new System.Drawing.Point(24, 534);
            this.tlbl9.Name = "tlbl9";
            this.tlbl9.Size = new System.Drawing.Size(218, 28);
            this.tlbl9.TabIndex = 13;
            this.tlbl9.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl5
            // 
            this.clbl5.AutoSize = true;
            this.clbl5.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl5.Location = new System.Drawing.Point(22, 484);
            this.clbl5.Name = "clbl5";
            this.clbl5.Size = new System.Drawing.Size(421, 39);
            this.clbl5.TabIndex = 12;
            this.clbl5.Text = "Basic Graph Theory";
            // 
            // tlbl8
            // 
            this.tlbl8.AutoSize = true;
            this.tlbl8.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl8.ForeColor = System.Drawing.Color.Black;
            this.tlbl8.Location = new System.Drawing.Point(24, 447);
            this.tlbl8.Name = "tlbl8";
            this.tlbl8.Size = new System.Drawing.Size(227, 28);
            this.tlbl8.TabIndex = 11;
            this.tlbl8.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl7
            // 
            this.tlbl7.AutoSize = true;
            this.tlbl7.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl7.ForeColor = System.Drawing.Color.Black;
            this.tlbl7.Location = new System.Drawing.Point(24, 419);
            this.tlbl7.Name = "tlbl7";
            this.tlbl7.Size = new System.Drawing.Size(218, 28);
            this.tlbl7.TabIndex = 10;
            this.tlbl7.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl4
            // 
            this.clbl4.AutoSize = true;
            this.clbl4.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl4.Location = new System.Drawing.Point(22, 369);
            this.clbl4.Name = "clbl4";
            this.clbl4.Size = new System.Drawing.Size(421, 39);
            this.clbl4.TabIndex = 9;
            this.clbl4.Text = "Basic Graph Theory";
            // 
            // tlbl6
            // 
            this.tlbl6.AutoSize = true;
            this.tlbl6.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl6.ForeColor = System.Drawing.Color.Black;
            this.tlbl6.Location = new System.Drawing.Point(24, 331);
            this.tlbl6.Name = "tlbl6";
            this.tlbl6.Size = new System.Drawing.Size(227, 28);
            this.tlbl6.TabIndex = 8;
            this.tlbl6.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl5
            // 
            this.tlbl5.AutoSize = true;
            this.tlbl5.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl5.ForeColor = System.Drawing.Color.Black;
            this.tlbl5.Location = new System.Drawing.Point(24, 303);
            this.tlbl5.Name = "tlbl5";
            this.tlbl5.Size = new System.Drawing.Size(218, 28);
            this.tlbl5.TabIndex = 7;
            this.tlbl5.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl3
            // 
            this.clbl3.AutoSize = true;
            this.clbl3.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl3.Location = new System.Drawing.Point(22, 253);
            this.clbl3.Name = "clbl3";
            this.clbl3.Size = new System.Drawing.Size(421, 39);
            this.clbl3.TabIndex = 6;
            this.clbl3.Text = "Basic Graph Theory";
            // 
            // tlbl4
            // 
            this.tlbl4.AutoSize = true;
            this.tlbl4.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl4.ForeColor = System.Drawing.Color.Black;
            this.tlbl4.Location = new System.Drawing.Point(24, 214);
            this.tlbl4.Name = "tlbl4";
            this.tlbl4.Size = new System.Drawing.Size(227, 28);
            this.tlbl4.TabIndex = 5;
            this.tlbl4.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl3
            // 
            this.tlbl3.AutoSize = true;
            this.tlbl3.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl3.ForeColor = System.Drawing.Color.Black;
            this.tlbl3.Location = new System.Drawing.Point(24, 186);
            this.tlbl3.Name = "tlbl3";
            this.tlbl3.Size = new System.Drawing.Size(218, 28);
            this.tlbl3.TabIndex = 4;
            this.tlbl3.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl2
            // 
            this.clbl2.AutoSize = true;
            this.clbl2.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl2.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl2.Location = new System.Drawing.Point(22, 136);
            this.clbl2.Name = "clbl2";
            this.clbl2.Size = new System.Drawing.Size(421, 39);
            this.clbl2.TabIndex = 3;
            this.clbl2.Text = "Basic Graph Theory";
            // 
            // tlbl2
            // 
            this.tlbl2.AutoSize = true;
            this.tlbl2.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl2.ForeColor = System.Drawing.Color.Black;
            this.tlbl2.Location = new System.Drawing.Point(24, 98);
            this.tlbl2.Name = "tlbl2";
            this.tlbl2.Size = new System.Drawing.Size(227, 28);
            this.tlbl2.TabIndex = 2;
            this.tlbl2.Text = "Tues: 08:00 - 11:00 ";
            // 
            // tlbl1
            // 
            this.tlbl1.AutoSize = true;
            this.tlbl1.Font = new System.Drawing.Font("Century Schoolbook", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlbl1.ForeColor = System.Drawing.Color.Black;
            this.tlbl1.Location = new System.Drawing.Point(24, 70);
            this.tlbl1.Name = "tlbl1";
            this.tlbl1.Size = new System.Drawing.Size(218, 28);
            this.tlbl1.TabIndex = 1;
            this.tlbl1.Text = "Sun: 08:00 - 11:00 ";
            // 
            // clbl1
            // 
            this.clbl1.AutoSize = true;
            this.clbl1.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbl1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.clbl1.Location = new System.Drawing.Point(22, 20);
            this.clbl1.Name = "clbl1";
            this.clbl1.Size = new System.Drawing.Size(421, 39);
            this.clbl1.TabIndex = 0;
            this.clbl1.Text = "Basic Graph Theory";
            // 
            // finalPnl
            // 
            this.finalPnl.Controls.Add(this.pageShow);
            this.finalPnl.Controls.Add(this.nxtBtn);
            this.finalPnl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.finalPnl.Location = new System.Drawing.Point(0, 695);
            this.finalPnl.Name = "finalPnl";
            this.finalPnl.Size = new System.Drawing.Size(793, 53);
            this.finalPnl.TabIndex = 5;
            // 
            // pageShow
            // 
            this.pageShow.AutoSize = true;
            this.pageShow.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pageShow.ForeColor = System.Drawing.Color.White;
            this.pageShow.Location = new System.Drawing.Point(9, 0);
            this.pageShow.Name = "pageShow";
            this.pageShow.Size = new System.Drawing.Size(54, 30);
            this.pageShow.TabIndex = 7;
            this.pageShow.Text = "Page";
            // 
            // nxtBtn
            // 
            this.nxtBtn.BackColor = System.Drawing.Color.Red;
            this.nxtBtn.FlatAppearance.BorderSize = 0;
            this.nxtBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nxtBtn.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nxtBtn.ForeColor = System.Drawing.Color.White;
            this.nxtBtn.Image = global::SchedulingWizard.Properties.Resources.icons8_search_more_32px;
            this.nxtBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nxtBtn.Location = new System.Drawing.Point(554, -1);
            this.nxtBtn.Name = "nxtBtn";
            this.nxtBtn.Size = new System.Drawing.Size(239, 54);
            this.nxtBtn.TabIndex = 6;
            this.nxtBtn.Text = "Next Result";
            this.nxtBtn.UseVisualStyleBackColor = false;
            this.nxtBtn.Click += new System.EventHandler(this.nxtPage);
            // 
            // introductoryPnl
            // 
            this.introductoryPnl.Controls.Add(this.pictureBox1);
            this.introductoryPnl.Controls.Add(this.button3);
            this.introductoryPnl.Controls.Add(this.panel4);
            this.introductoryPnl.Controls.Add(this.routineLabel);
            this.introductoryPnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.introductoryPnl.Location = new System.Drawing.Point(0, 0);
            this.introductoryPnl.Name = "introductoryPnl";
            this.introductoryPnl.Size = new System.Drawing.Size(793, 87);
            this.introductoryPnl.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SchedulingWizard.Properties.Resources.icons8_todo_list_200px;
            this.pictureBox1.Location = new System.Drawing.Point(202, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Image = global::SchedulingWizard.Properties.Resources.icons8_arrow_pointing_left_30px;
            this.button3.Location = new System.Drawing.Point(14, 21);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 41);
            this.button3.TabIndex = 7;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.prevPage);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Location = new System.Drawing.Point(660, 21);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(123, 41);
            this.panel4.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightCoral;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkRed;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 41);
            this.button2.TabIndex = 1;
            this.button2.Text = "-";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.minimizePage);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkRed;
            this.button1.Location = new System.Drawing.Point(58, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 41);
            this.button1.TabIndex = 0;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.close);
            // 
            // routineLabel
            // 
            this.routineLabel.AutoSize = true;
            this.routineLabel.Font = new System.Drawing.Font("Palatino Linotype", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.routineLabel.ForeColor = System.Drawing.Color.Maroon;
            this.routineLabel.Location = new System.Drawing.Point(295, 9);
            this.routineLabel.Name = "routineLabel";
            this.routineLabel.Size = new System.Drawing.Size(195, 64);
            this.routineLabel.TabIndex = 5;
            this.routineLabel.Text = "Routine";
            this.routineLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // scheduleResults
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(793, 748);
            this.Controls.Add(this.introductoryPnl);
            this.Controls.Add(this.finalPnl);
            this.Controls.Add(this.resultShowPnl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "scheduleResults";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "scheduleResults";
            this.resultShowPnl.ResumeLayout(false);
            this.resultShowPnl.PerformLayout();
            this.finalPnl.ResumeLayout(false);
            this.finalPnl.PerformLayout();
            this.introductoryPnl.ResumeLayout(false);
            this.introductoryPnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel resultShowPnl;
        private System.Windows.Forms.Label tlbl10;
        private System.Windows.Forms.Label tlbl9;
        private System.Windows.Forms.Label clbl5;
        private System.Windows.Forms.Label tlbl8;
        private System.Windows.Forms.Label tlbl7;
        private System.Windows.Forms.Label clbl4;
        private System.Windows.Forms.Label tlbl6;
        private System.Windows.Forms.Label clbl3;
        private System.Windows.Forms.Label tlbl4;
        private System.Windows.Forms.Label tlbl3;
        private System.Windows.Forms.Label clbl2;
        private System.Windows.Forms.Label tlbl2;
        private System.Windows.Forms.Label tlbl1;
        private System.Windows.Forms.Label clbl1;
        private System.Windows.Forms.Panel finalPnl;
        private System.Windows.Forms.Button nxtBtn;
        private System.Windows.Forms.Panel introductoryPnl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label routineLabel;
        private System.Windows.Forms.Label tlbl5;
        private System.Windows.Forms.Label pageShow;
    }
}