﻿namespace SchedulingWizard.frames
{
    partial class adminDropUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.nlbl1 = new System.Windows.Forms.Label();
            this.ulbl1 = new System.Windows.Forms.Label();
            this.ulbl2 = new System.Windows.Forms.Label();
            this.nlbl2 = new System.Windows.Forms.Label();
            this.ulbl4 = new System.Windows.Forms.Label();
            this.nlbl4 = new System.Windows.Forms.Label();
            this.ulbl3 = new System.Windows.Forms.Label();
            this.nlbl3 = new System.Windows.Forms.Label();
            this.ulbl7 = new System.Windows.Forms.Label();
            this.nlbl7 = new System.Windows.Forms.Label();
            this.ulbl6 = new System.Windows.Forms.Label();
            this.nlbl6 = new System.Windows.Forms.Label();
            this.ulbl5 = new System.Windows.Forms.Label();
            this.nlbl5 = new System.Windows.Forms.Label();
            this.ulbl8 = new System.Windows.Forms.Label();
            this.nlbl8 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.rbtn1 = new System.Windows.Forms.RadioButton();
            this.rbtn2 = new System.Windows.Forms.RadioButton();
            this.rbtn3 = new System.Windows.Forms.RadioButton();
            this.rbtn6 = new System.Windows.Forms.RadioButton();
            this.rbtn5 = new System.Windows.Forms.RadioButton();
            this.rbtn4 = new System.Windows.Forms.RadioButton();
            this.rbtn8 = new System.Windows.Forms.RadioButton();
            this.rbtn7 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(118, 12);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(505, 51);
            this.Title.TabIndex = 1;
            this.Title.Text = "Showing User Information";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(629, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(34, 35);
            this.button2.TabIndex = 7;
            this.button2.Text = "_";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.minimizeWindow);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(669, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 35);
            this.button1.TabIndex = 6;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.closeWindow);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = global::SchedulingWizard.Properties.Resources.icons8_arrow_pointing_left_30px;
            this.button5.Location = new System.Drawing.Point(12, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 35);
            this.button5.TabIndex = 10;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.prevPage);
            // 
            // nlbl1
            // 
            this.nlbl1.AutoSize = true;
            this.nlbl1.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl1.ForeColor = System.Drawing.Color.White;
            this.nlbl1.Location = new System.Drawing.Point(34, 129);
            this.nlbl1.Name = "nlbl1";
            this.nlbl1.Size = new System.Drawing.Size(43, 39);
            this.nlbl1.TabIndex = 11;
            this.nlbl1.Text = "1.";
            // 
            // ulbl1
            // 
            this.ulbl1.AutoSize = true;
            this.ulbl1.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl1.ForeColor = System.Drawing.Color.White;
            this.ulbl1.Location = new System.Drawing.Point(99, 129);
            this.ulbl1.Name = "ulbl1";
            this.ulbl1.Size = new System.Drawing.Size(145, 39);
            this.ulbl1.TabIndex = 12;
            this.ulbl1.Text = "first User";
            // 
            // ulbl2
            // 
            this.ulbl2.AutoSize = true;
            this.ulbl2.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl2.ForeColor = System.Drawing.Color.White;
            this.ulbl2.Location = new System.Drawing.Point(99, 183);
            this.ulbl2.Name = "ulbl2";
            this.ulbl2.Size = new System.Drawing.Size(145, 39);
            this.ulbl2.TabIndex = 14;
            this.ulbl2.Text = "first User";
            // 
            // nlbl2
            // 
            this.nlbl2.AutoSize = true;
            this.nlbl2.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl2.ForeColor = System.Drawing.Color.White;
            this.nlbl2.Location = new System.Drawing.Point(34, 183);
            this.nlbl2.Name = "nlbl2";
            this.nlbl2.Size = new System.Drawing.Size(43, 39);
            this.nlbl2.TabIndex = 13;
            this.nlbl2.Text = "1.";
            // 
            // ulbl4
            // 
            this.ulbl4.AutoSize = true;
            this.ulbl4.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl4.ForeColor = System.Drawing.Color.White;
            this.ulbl4.Location = new System.Drawing.Point(99, 296);
            this.ulbl4.Name = "ulbl4";
            this.ulbl4.Size = new System.Drawing.Size(145, 39);
            this.ulbl4.TabIndex = 18;
            this.ulbl4.Text = "first User";
            // 
            // nlbl4
            // 
            this.nlbl4.AutoSize = true;
            this.nlbl4.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl4.ForeColor = System.Drawing.Color.White;
            this.nlbl4.Location = new System.Drawing.Point(34, 296);
            this.nlbl4.Name = "nlbl4";
            this.nlbl4.Size = new System.Drawing.Size(43, 39);
            this.nlbl4.TabIndex = 17;
            this.nlbl4.Text = "1.";
            // 
            // ulbl3
            // 
            this.ulbl3.AutoSize = true;
            this.ulbl3.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl3.ForeColor = System.Drawing.Color.White;
            this.ulbl3.Location = new System.Drawing.Point(99, 240);
            this.ulbl3.Name = "ulbl3";
            this.ulbl3.Size = new System.Drawing.Size(145, 39);
            this.ulbl3.TabIndex = 16;
            this.ulbl3.Text = "first User";
            // 
            // nlbl3
            // 
            this.nlbl3.AutoSize = true;
            this.nlbl3.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl3.ForeColor = System.Drawing.Color.White;
            this.nlbl3.Location = new System.Drawing.Point(34, 240);
            this.nlbl3.Name = "nlbl3";
            this.nlbl3.Size = new System.Drawing.Size(43, 39);
            this.nlbl3.TabIndex = 15;
            this.nlbl3.Text = "1.";
            // 
            // ulbl7
            // 
            this.ulbl7.AutoSize = true;
            this.ulbl7.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl7.ForeColor = System.Drawing.Color.White;
            this.ulbl7.Location = new System.Drawing.Point(99, 463);
            this.ulbl7.Name = "ulbl7";
            this.ulbl7.Size = new System.Drawing.Size(145, 39);
            this.ulbl7.TabIndex = 24;
            this.ulbl7.Text = "first User";
            // 
            // nlbl7
            // 
            this.nlbl7.AutoSize = true;
            this.nlbl7.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl7.ForeColor = System.Drawing.Color.White;
            this.nlbl7.Location = new System.Drawing.Point(34, 463);
            this.nlbl7.Name = "nlbl7";
            this.nlbl7.Size = new System.Drawing.Size(43, 39);
            this.nlbl7.TabIndex = 23;
            this.nlbl7.Text = "1.";
            // 
            // ulbl6
            // 
            this.ulbl6.AutoSize = true;
            this.ulbl6.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl6.ForeColor = System.Drawing.Color.White;
            this.ulbl6.Location = new System.Drawing.Point(99, 407);
            this.ulbl6.Name = "ulbl6";
            this.ulbl6.Size = new System.Drawing.Size(145, 39);
            this.ulbl6.TabIndex = 22;
            this.ulbl6.Text = "first User";
            // 
            // nlbl6
            // 
            this.nlbl6.AutoSize = true;
            this.nlbl6.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl6.ForeColor = System.Drawing.Color.White;
            this.nlbl6.Location = new System.Drawing.Point(34, 407);
            this.nlbl6.Name = "nlbl6";
            this.nlbl6.Size = new System.Drawing.Size(43, 39);
            this.nlbl6.TabIndex = 21;
            this.nlbl6.Text = "1.";
            // 
            // ulbl5
            // 
            this.ulbl5.AutoSize = true;
            this.ulbl5.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl5.ForeColor = System.Drawing.Color.White;
            this.ulbl5.Location = new System.Drawing.Point(99, 352);
            this.ulbl5.Name = "ulbl5";
            this.ulbl5.Size = new System.Drawing.Size(145, 39);
            this.ulbl5.TabIndex = 20;
            this.ulbl5.Text = "first User";
            // 
            // nlbl5
            // 
            this.nlbl5.AutoSize = true;
            this.nlbl5.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl5.ForeColor = System.Drawing.Color.White;
            this.nlbl5.Location = new System.Drawing.Point(34, 352);
            this.nlbl5.Name = "nlbl5";
            this.nlbl5.Size = new System.Drawing.Size(43, 39);
            this.nlbl5.TabIndex = 19;
            this.nlbl5.Text = "1.";
            // 
            // ulbl8
            // 
            this.ulbl8.AutoSize = true;
            this.ulbl8.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ulbl8.ForeColor = System.Drawing.Color.White;
            this.ulbl8.Location = new System.Drawing.Point(99, 515);
            this.ulbl8.Name = "ulbl8";
            this.ulbl8.Size = new System.Drawing.Size(145, 39);
            this.ulbl8.TabIndex = 26;
            this.ulbl8.Text = "first User";
            // 
            // nlbl8
            // 
            this.nlbl8.AutoSize = true;
            this.nlbl8.Font = new System.Drawing.Font("Calisto MT", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nlbl8.ForeColor = System.Drawing.Color.White;
            this.nlbl8.Location = new System.Drawing.Point(34, 515);
            this.nlbl8.Name = "nlbl8";
            this.nlbl8.Size = new System.Drawing.Size(43, 39);
            this.nlbl8.TabIndex = 25;
            this.nlbl8.Text = "1.";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::SchedulingWizard.Properties.Resources.icons8_search_more_32px;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(506, 580);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(199, 37);
            this.button3.TabIndex = 27;
            this.button3.Text = "Next page";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.nxtPage);
            // 
            // rbtn1
            // 
            this.rbtn1.AutoSize = true;
            this.rbtn1.Location = new System.Drawing.Point(594, 138);
            this.rbtn1.Name = "rbtn1";
            this.rbtn1.Size = new System.Drawing.Size(17, 16);
            this.rbtn1.TabIndex = 28;
            this.rbtn1.TabStop = true;
            this.rbtn1.UseVisualStyleBackColor = true;
            // 
            // rbtn2
            // 
            this.rbtn2.AutoSize = true;
            this.rbtn2.Location = new System.Drawing.Point(594, 192);
            this.rbtn2.Name = "rbtn2";
            this.rbtn2.Size = new System.Drawing.Size(17, 16);
            this.rbtn2.TabIndex = 29;
            this.rbtn2.TabStop = true;
            this.rbtn2.UseVisualStyleBackColor = true;
            // 
            // rbtn3
            // 
            this.rbtn3.AutoSize = true;
            this.rbtn3.Location = new System.Drawing.Point(594, 249);
            this.rbtn3.Name = "rbtn3";
            this.rbtn3.Size = new System.Drawing.Size(17, 16);
            this.rbtn3.TabIndex = 30;
            this.rbtn3.TabStop = true;
            this.rbtn3.UseVisualStyleBackColor = true;
            // 
            // rbtn6
            // 
            this.rbtn6.AutoSize = true;
            this.rbtn6.Location = new System.Drawing.Point(594, 416);
            this.rbtn6.Name = "rbtn6";
            this.rbtn6.Size = new System.Drawing.Size(17, 16);
            this.rbtn6.TabIndex = 33;
            this.rbtn6.TabStop = true;
            this.rbtn6.UseVisualStyleBackColor = true;
            // 
            // rbtn5
            // 
            this.rbtn5.AutoSize = true;
            this.rbtn5.Location = new System.Drawing.Point(594, 359);
            this.rbtn5.Name = "rbtn5";
            this.rbtn5.Size = new System.Drawing.Size(17, 16);
            this.rbtn5.TabIndex = 32;
            this.rbtn5.TabStop = true;
            this.rbtn5.UseVisualStyleBackColor = true;
            // 
            // rbtn4
            // 
            this.rbtn4.AutoSize = true;
            this.rbtn4.Location = new System.Drawing.Point(594, 305);
            this.rbtn4.Name = "rbtn4";
            this.rbtn4.Size = new System.Drawing.Size(17, 16);
            this.rbtn4.TabIndex = 31;
            this.rbtn4.TabStop = true;
            this.rbtn4.UseVisualStyleBackColor = true;
            // 
            // rbtn8
            // 
            this.rbtn8.AutoSize = true;
            this.rbtn8.Location = new System.Drawing.Point(594, 524);
            this.rbtn8.Name = "rbtn8";
            this.rbtn8.Size = new System.Drawing.Size(17, 16);
            this.rbtn8.TabIndex = 35;
            this.rbtn8.TabStop = true;
            this.rbtn8.UseVisualStyleBackColor = true;
            // 
            // rbtn7
            // 
            this.rbtn7.AutoSize = true;
            this.rbtn7.Location = new System.Drawing.Point(594, 472);
            this.rbtn7.Name = "rbtn7";
            this.rbtn7.Size = new System.Drawing.Size(17, 16);
            this.rbtn7.TabIndex = 34;
            this.rbtn7.TabStop = true;
            this.rbtn7.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(41, 572);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(96, 44);
            this.button4.TabIndex = 36;
            this.button4.Text = "Drop";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.dropUser);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(143, 572);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(96, 44);
            this.button6.TabIndex = 37;
            this.button6.Text = "View";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.viewInfo);
            // 
            // adminDropUser
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(717, 638);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.rbtn8);
            this.Controls.Add(this.rbtn7);
            this.Controls.Add(this.rbtn6);
            this.Controls.Add(this.rbtn5);
            this.Controls.Add(this.rbtn4);
            this.Controls.Add(this.rbtn3);
            this.Controls.Add(this.rbtn2);
            this.Controls.Add(this.rbtn1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.ulbl8);
            this.Controls.Add(this.nlbl8);
            this.Controls.Add(this.ulbl7);
            this.Controls.Add(this.nlbl7);
            this.Controls.Add(this.ulbl6);
            this.Controls.Add(this.nlbl6);
            this.Controls.Add(this.ulbl5);
            this.Controls.Add(this.nlbl5);
            this.Controls.Add(this.ulbl4);
            this.Controls.Add(this.nlbl4);
            this.Controls.Add(this.ulbl3);
            this.Controls.Add(this.nlbl3);
            this.Controls.Add(this.ulbl2);
            this.Controls.Add(this.nlbl2);
            this.Controls.Add(this.ulbl1);
            this.Controls.Add(this.nlbl1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "adminDropUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "adminDropUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label nlbl1;
        private System.Windows.Forms.Label ulbl1;
        private System.Windows.Forms.Label ulbl2;
        private System.Windows.Forms.Label nlbl2;
        private System.Windows.Forms.Label ulbl4;
        private System.Windows.Forms.Label nlbl4;
        private System.Windows.Forms.Label ulbl3;
        private System.Windows.Forms.Label nlbl3;
        private System.Windows.Forms.Label ulbl7;
        private System.Windows.Forms.Label nlbl7;
        private System.Windows.Forms.Label ulbl6;
        private System.Windows.Forms.Label nlbl6;
        private System.Windows.Forms.Label ulbl5;
        private System.Windows.Forms.Label nlbl5;
        private System.Windows.Forms.Label ulbl8;
        private System.Windows.Forms.Label nlbl8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton rbtn1;
        private System.Windows.Forms.RadioButton rbtn2;
        private System.Windows.Forms.RadioButton rbtn3;
        private System.Windows.Forms.RadioButton rbtn6;
        private System.Windows.Forms.RadioButton rbtn5;
        private System.Windows.Forms.RadioButton rbtn4;
        private System.Windows.Forms.RadioButton rbtn8;
        private System.Windows.Forms.RadioButton rbtn7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
    }
}